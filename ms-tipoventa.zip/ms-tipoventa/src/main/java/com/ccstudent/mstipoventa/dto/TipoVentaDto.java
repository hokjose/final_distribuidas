package com.ccstudent.mstipoventa.dto;

import lombok.Data;

@Data
public class TipoVentaDto {
    private Long id;
    private String tipoventa;
}
