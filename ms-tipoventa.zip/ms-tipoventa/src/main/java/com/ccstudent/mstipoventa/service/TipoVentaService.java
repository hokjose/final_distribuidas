package com.ccstudent.mstipoventa.service;

import com.ccstudent.mstipoventa.entity.TipoVenta;

import java.util.List;

public interface TipoVentaService {
    List<TipoVenta> findAll();
}
