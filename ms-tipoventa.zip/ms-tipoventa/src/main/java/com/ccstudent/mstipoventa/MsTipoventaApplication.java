package com.ccstudent.mstipoventa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsTipoventaApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsTipoventaApplication.class, args);
    }

}
