package com.ccstudent.msventa.dto;

import lombok.Data;

@Data
public class FormaPagoDto {
    private Long id;
    private String formapago;
}
