package com.ccstudent.msventa.repository;

import com.ccstudent.msventa.entity.Venta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VentaRepository extends JpaRepository<Venta, Long> {
}
