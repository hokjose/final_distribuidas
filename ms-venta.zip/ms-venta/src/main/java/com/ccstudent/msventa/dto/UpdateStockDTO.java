package com.ccstudent.msventa.dto;

import lombok.Data;

@Data
public class UpdateStockDTO {
    private Integer stock;
}
