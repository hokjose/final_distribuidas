package com.ccstudent.msventa.dto;

import lombok.Data;

@Data
public class TipoVentaDto {
    private Long id;
    private String tipoventa;
}
