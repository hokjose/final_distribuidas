package com.ccstudent.mscliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsClienteApplicationTests {

    @Test
    void contextLoads() {
    }

}
