package com.ccstudent.msformapago.dto;

import lombok.Data;

@Data
public class FormaPagoDto {
    private Long id;
    private String formapago;
}
