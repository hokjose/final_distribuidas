package com.ccstudent.msformapago.service;

import com.ccstudent.msformapago.entity.FormaPago;

import java.util.List;

public interface FormaPagoService {
    List<FormaPago> findAll();

}