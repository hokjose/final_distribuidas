package com.ccstudent.msformapago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsFormapagoApplicationTests {

    @Test
    void contextLoads() {
    }

}
